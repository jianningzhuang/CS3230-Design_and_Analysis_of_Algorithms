/*
Name:
Describe your algorithm and explain your time complexity here.

Prove the correctness of your algorithm here:
*/

import java.util.*;

class TaskA {
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		int N = sc.nextInt();
		int[] a = new int[N * 2];
		int[] b = new int[N * 2];
		for (int i = 0; i < N * 2; i++) {
			a[i] = sc.nextInt();
			b[i] = sc.nextInt();
		}
		long answer = 0;

		// write your code here
		
		System.out.println(answer);
	}
}
import java.util.*;

/*
ID:
Describe your algorithm and explain your time complexity here.
*/
public class Main{
    ///You can declare class static variables in case you need it.

    public static int solve(int n, int m) {
        ///Return number of trials in the worst case.

        return 0;
    }
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        int n = Scanner.nextInt();
        int m = Scanner.nextInt();
        System.out.print(solve(n, m));
    }
}

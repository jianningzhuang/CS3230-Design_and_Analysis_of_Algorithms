/*
Name:
Describe your algorithm and explain your time complexity here.
*/
#include <cstdio>

int main(){
    int N, P;
    scanf("%d %d", &N, &P);
    int arr[N];
    for (int i = 0; i < N; i++) {
        scanf("%d", &arr[i]);
    }
	
	int answer = 0;
	// write your code here
    printf("%d\n", answer);
	return 0;
}

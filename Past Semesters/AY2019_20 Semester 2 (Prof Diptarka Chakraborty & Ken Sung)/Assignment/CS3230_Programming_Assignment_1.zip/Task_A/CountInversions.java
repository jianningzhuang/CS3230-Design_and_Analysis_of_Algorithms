/*
Name:
Describe your algorithm and explain your time complexity here.
*/
import java.util.*;

class CountInversions {

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int N = sc.nextInt();
        int P = sc.nextInt();
        int arr[] = new int[N];
        for (int i = 0; i < N; i++) {
            arr[i] = sc.nextInt();
        }
		
		int answer = 0;
		// write your code here
        System.out.println(answer);
    }
    
}

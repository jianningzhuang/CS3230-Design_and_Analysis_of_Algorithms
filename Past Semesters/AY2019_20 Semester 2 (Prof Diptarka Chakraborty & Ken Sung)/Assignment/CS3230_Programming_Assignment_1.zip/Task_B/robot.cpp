/*
Name:
Describe your algorithm and explain your time complexity here.
*/
#include <cstdio>

int main(){
    int N, B;
    scanf("%d %d", &N, &B);
    int arr[N];
    for (int i = 0; i < N; i++) {
        scanf("%d", &arr[i]);
    }
	int W[N];
    for (int i = 0; i < N; i++) {
        scanf("%d", &W[i]);
    }
	int C[N];
    for (int i = 0; i < N; i++) {
        scanf("%d", &C[i]);
    }
	
	int answer = 0;
	// write your code here
    printf("%d\n", answer);
	return 0;
}

/*
Solution:
In the merging step, we use an array to keep track of the number of values in the left half with each remainder modulo P. Then, every time we take an element arr[j] from the right half, we use the array to determine the number of elements with remainder (P - arr[j] % P) modulo P. 

Time complexity analysis:
T(N) = 2T(N/2) + O(N)
T(N) = O(N log N) by case 2 of Master Theorem

Common Mistakes:
Make sure to use the same array for each merge step as declaring a new array for each merge step will result in O(N^2) time complexity since there are N merge steps. Using a hash map will also be penalised as although hash map operations are constant time on average, they may not perform well in the worst case.
*/
import java.util.*;

class CountInversions {
	
    private static int mergeAndCount(int[] arr, int[] moduloCount, int l, int m, int r, int p) 
    { 
        int[] left = Arrays.copyOfRange(arr, l, m + 1); 
 
        // count the number of elements for each remainder modulo p in left half
        for (int i = 0; i < left.length; i++) {
            moduloCount[left[i] % p]++;
        }
  
        int[] right = Arrays.copyOfRange(arr, m + 1, r + 1); 
  
        int i = 0, j = 0, k = l, swaps = 0; 
  
        while (i < left.length && j < right.length) { 
            if (left[i] <= right[j]) {
                // if we take element from left, update the count
                moduloCount[left[i] % p]--;
                arr[k++] = left[i++]; 
            }
            else { 
                // if we take element from the right, calculate special inversions using the count
                swaps += moduloCount[(p - right[j] % p) % p];
                arr[k++] = right[j++]; 
            } 
        } 
  
        while (i < left.length) {
            moduloCount[left[i] % p]--;
            arr[k++] = left[i++]; 
        }
  
        while (j < right.length) 
            arr[k++] = right[j++]; 
  
        return swaps; 
    } 
  
    private static int mergeSortAndCount(int[] arr, int[] moduloCount, int l, int r, int p) 
    { 
        int count = 0; 
  
        if (l < r) { 
            int m = (l + r) / 2; 
            count += mergeSortAndCount(arr, moduloCount, l, m, p); 
            count += mergeSortAndCount(arr, moduloCount, m + 1, r, p); 
            count += mergeAndCount(arr, moduloCount, l, m, r, p); 
        } 
  
        return count; 
    } 
    
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int N = sc.nextInt();
        int P = sc.nextInt();
        int arr[] = new int[N];
        for (int i = 0; i < N; i++) {
            arr[i] = sc.nextInt();
        }
        
        int answer = 0;
        answer = mergeSortAndCount(arr, new int[P], 0, N - 1, P);
        System.out.println(answer);
    }

}

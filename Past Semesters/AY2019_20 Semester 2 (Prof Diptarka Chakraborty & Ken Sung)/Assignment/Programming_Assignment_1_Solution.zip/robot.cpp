/*
Solution:
First we need to calculate that the total number of charges needed for robot i to sort the boxes is 2 for each inversion (arr[j], arr[k]) where arr[j] > W[i] * arr[k] (which we shall call a significant inversion) and 1 for each inversion where arr[j] <= W[i] * arr[k]. This can be rephrased as the number of significant inversions + the total number of inversions, which can be calculated using the algorithms in the 2 URLs given in the assignment.

Next, we observe that for 2 robots i and j, if W[i] <= W[j] then for the same row of boxes, robot i will need at least as many charges if not more than robot j to sort the boxes. This is because if arr[j] > W[j] * arr[k] then since W[j] >= W[i] it must also be true that arr[j] > W[i] * arr[k] so any significant inversion for robot j will also be significant for robot i. 

Let B[i] be the number of charges needed by robot i to sort the boxes. If we sort the robots in increasing W[i], then by the previous point the values of B[i] are decreasing.
Therefore, we can binary search for the robot with the smallest W[i] such that B[i] <= B. Calculating the value of B[i] for all robots will be too slow, but since we only need to access log N values to binary search, we only need to calculate the values that we access and each value can be calculated in O(N log N) time.

Finally, once we get the smallest W[i] which can sort in B charges, we can look through all the robots and find the robot with the minimum cost across all robots j such that W[j] >= W[i]. This cost is the answer required.

Time complexity analysis:
Each iteration of the binary search takes O(N log N) time as stated in the 2 URLs. There are N values in the search range so we need log N iteations of the binary search. Hence, the total time complexity is O(N log N * log N) = O(N log^2 N).

Common mistakes:
When checking for significant inversions, the values need to be casted to 64-bit integers to prevent integer overflows when multiplying the values.

We also give a small penalisation if the binary search is done on a range non-dependent on N such as [1, 2^31].
*/
#include <cstdio>
  
int _mergeSort(int arr[], int temp[], int left, int right, int w); 
int merge(int arr[], int temp[], int left, int mid, int right, int w); 
  
int mergeSort(int arr[], int array_size, int w) 
{ 
    int temp[array_size]; 
    return _mergeSort(arr, temp, 0, array_size - 1, w); 
} 

int _mergeSort(int arr[], int temp[], int left, int right, int w) 
{ 
    int mid, inv_count = 0; 
    if (right > left) { 
        mid = (right + left) / 2; 
        inv_count = _mergeSort(arr, temp, left, mid, w); 
        inv_count += _mergeSort(arr, temp, mid + 1, right, w); 
        inv_count += merge(arr, temp, left, mid + 1, right, w); 
    } 
    return inv_count; 
} 

int merge(int arr[], int temp[], int left, 
          int mid, int right, int w) 
{ 
    int i, j, k; 
    int inv_count = 0; 
  
    i = left; 
    j = mid; 
    k = left; 
  
    // First pass to count number of significant inversions 
    while ((i <= mid - 1) && (j <= right)) { 
        if (arr[i] > (long long)w * arr[j]) { 
            inv_count += (mid - i); 
            j++; 
        } 
        else { 
            i++; 
        } 
    } 
  
    i = left; 
    j = mid; 
    k = left; 
  
    // Second pass to merge the two sorted arrays 
    while ((i <= mid - 1) && (j <= right)) { 
        if (arr[i] <= arr[j]) { 
            temp[k++] = arr[i++]; 
        } 
        else { 
            temp[k++] = arr[j++]; 
            inv_count += (mid - i);
        } 
    } 
  
    while (i <= mid - 1) 
        temp[k++] = arr[i++]; 
  
    while (j <= right) 
        temp[k++] = arr[j++]; 
  
    for (i = left; i <= right; i++) 
        arr[i] = temp[i]; 
  
    return inv_count; 
} 
    
// binary search for the smallest possible W[i]
// such that the robot can perform all the swaps within b charges
int binary_search(int arr[], int W[], int array_size, int b) 
{
    int temparr[array_size], tempW[array_size];
    for (int i = 0; i < array_size; i++) {
        tempW[i] = W[i];
    }
    mergeSort(tempW, array_size, 0);
    int left = 0, right = array_size - 1;
    while (left < right) {
        for (int i = 0; i < array_size; i++) {
            temparr[i] = arr[i];
        }
        int mid = (left + right) / 2;
        if (mergeSort(temparr, array_size, tempW[mid]) <= b) {
            right = mid;
        } else {
            left = mid + 1;
        }
    }
    return tempW[left];
}

int main(){
    int N, B;
    scanf("%d %d", &N, &B);
    int arr[N];
    for (int i = 0; i < N; i++) {
        scanf("%d", &arr[i]);
    }
	int W[N];
    for (int i = 0; i < N; i++) {
        scanf("%d", &W[i]);
    }
	int C[N];
    for (int i = 0; i < N; i++) {
        scanf("%d", &C[i]);
    }
	
	int answer = 0;
	int minimum_weight = binary_search(arr, W, N, B);
	
	// search for the minimum cost robot with W[i] >= the required minimum W[i]
	for (int i = 0; i < N; i++) {
	    if (W[i] >= minimum_weight) {
	        if (answer == 0 || C[i] < answer) {
	            answer = C[i];
	        }
	    }
	}
    printf("%d\n", answer);
	return 0;
}

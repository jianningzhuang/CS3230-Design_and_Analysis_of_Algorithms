/*
Solution:
In the merging step, we use an array to keep track of the number of values in the left half with each remainder modulo P. Then, every time we take an element arr[j] from the right half, we use the array to determine the number of elements with remainder (P - arr[j] % P) modulo P. 

Time complexity analysis:
T(N) = 2T(N/2) + O(N)
T(N) = O(N log N) by case 2 of Master Theorem

Common Mistakes:
Make sure to use the same array for each merge step as declaring a new array for each merge step will result in O(N^2) time complexity since there are N merge steps. Using a hash map will also be penalised as although hash map operations are constant time on average, they may not perform well in the worst case.
*/
#include <cstdio>

int _mergeSort(int arr[], int temp[], int modulo_count[], int left, int right, int p); 
int  merge(int arr[], int temp[], int modulo_count[], int left, int mid, int right, int p); 
  
int mergeSort(int arr[], int array_size, int p) 
{ 
    int temp[array_size], modulo_count[p];
	for (int i = 0; i < p; i++) {
		modulo_count[i] = 0;
	}
    return _mergeSort(arr, temp, modulo_count, 0, array_size - 1, p); 
} 

int _mergeSort(int arr[], int temp[], int modulo_count[], int left, int right, int p) 
{ 
    int mid, inv_count = 0; 
    if (right > left) { 
        for each of the parts */
        mid = (right + left) / 2; 
        inv_count += _mergeSort(arr, temp, modulo_count, left, mid, p); 
        inv_count += _mergeSort(arr, temp, modulo_count, mid + 1, right, p); 
        inv_count += merge(arr, temp, modulo_count, left, mid + 1, right, p); 
    } 
    return inv_count; 
} 

int merge(int arr[], int temp[], int modulo_count[], 
          int left, int mid, int right, int p) 
{ 
    // count the number of elements for each remainder modulo p in left half
    for (int i = left; i < mid; i++) {
        modulo_count[arr[i] % p]++;
    }
    
    int i, j, k, inv_count = 0; 
  
    i = left;
    j = mid;
    k = left;
    while ((i <= mid - 1) && (j <= right)) { 
        if (arr[i] <= arr[j]) { 
            // if we take element from left, update the count
            modulo_count[arr[i] % p]--;
            temp[k++] = arr[i++]; 
        } 
        else { 
            // if we take element from the right, calculate special inversions using the count
            inv_count += modulo_count[(p - arr[j] % p) % p];    
            temp[k++] = arr[j++];
        } 
    } 
  
    while (i <= mid - 1) {
        modulo_count[arr[i] % p]--;
        temp[k++] = arr[i++]; 
    }
  
    while (j <= right) 
        temp[k++] = arr[j++]; 
  
    for (i = left; i <= right; i++) 
        arr[i] = temp[i]; 
  
    return inv_count; 
} 

int main(){
    int N, P;
    scanf("%d %d", &N, &P);
    int arr[N];
    for (int i = 0; i < N; i++) {
        scanf("%d", &arr[i]);
    }
	
	int answer = 0;
	answer = mergeSort(arr, N, P);
    printf("%d\n", answer);
	return 0;
}
